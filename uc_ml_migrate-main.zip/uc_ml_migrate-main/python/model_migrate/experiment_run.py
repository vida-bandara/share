from model_migrate.mlflow import MLFlowEntityBase
from abc import abstractmethod
from typing import override
from functools import cached_property
import mlflow

class ExperimentRun(MLFlowEntityBase):

    _run_id: str

    @property
    def run_id(self):
        return self._run_id

    @abstractmethod
    def status(self):
        pass


class SrcExperimentRun(ExperimentRun):

    def __init__(self, run_id: str):
        self._run_id = run_id

    @override
    def status(self):
        print(f'      Source Experiment Run {self.__class__.__name__}, id: {self.run_id}')


class TgtExperimentRun(ExperimentRun):

    _experiment_id: str
    _src_exp_run: SrcExperimentRun

    def __init__(self,
                 experiment_id: str, 
                 src_exp_run: SrcExperimentRun):
        self._experiment_id = experiment_id
        self._src_exp_run = src_exp_run

    def experiment_id(self):
        return self._experiment_id

    @override
    def status(self):
        print(f'      Target Experiment Run {self.__class__.__name__}, migration clas for id: {self._src_exp_run.run_id}')

    @cached_property
    def run_id(self) -> str:
        """TgtExperimentRun can be instantiated without actually having an associated experiment run entity. However, 
        when it is created, it must be done in a way that it's relationship to it's source experiment run is known.
        Thus for all migrated experiment runs, there will be a tag `migration_source_run_id` which will be set to the 
        run_id of the source experiment run."""
        with self.mlflow_client() as client:
            runs = client.search_runs(
                experiment_ids=[self._experiment_id,],
                filter_string=f"tags.migration_source_run_id = '{self._src_exp_run.run_id}'")
            if len(runs)==0:
                with mlflow.start_run(experiment_id=self._experiment_id) as run:
                    mlflow.set_tag("migration_source_run_id", self._src_exp_run.run_id)
                    mlflow.set_tag("migration_upgrade_complete", False)
                    run_id = run.info.run_id
            else:
                run_id = runs[0].info.run_id
        return run_id

    def initialize_tgt_runs(self):
        # Initialization happens automatically once run_id is called,
        # initialize_tgt_runs is a conveninece method so migration team can inspect entities prior to upgrade
        _ = self.run_id
