from model_migrate.mlflow import MLFlowEntityBase
from model_migrate.registered_model_version import ModelVersion
from model_migrate.registered_model_version import WsRegisteredModelVersion, UcRegisteredModelVersion
from model_migrate.model_experiment import ModelExperiment, SrcModelExperiment, TgtModelExperiment

from mlflow.entities.model_registry.registered_model import RegisteredModel
from mlflow.entities.experiment import Experiment

from functools import cached_property
from abc import abstractmethod
from typing import override


class RegisteredModelBase(MLFlowEntityBase):

    _rm_name: str
    _artifact_location: str

    @cached_property
    def registered_model_name(self):
        """Will get or create a registered model to ensure that the registered model exists."""
        with self.mlflow_client() as client:
            try:
                client.create_registered_model(name=self._rm_name)
                print("Successfully created registered model: " + self._rm_name)
            except:
                # TODO: Add Explicit Exception
                print("Identified existing registered model: " + client.get_registered_model(name=self._rm_name).name)
        return self._rm_name

    @property
    def registered_model(self) -> RegisteredModel:
        with self.mlflow_client() as client:
            return client.get_registered_model(name=self.registered_model_name)

    @property
    def latest_version_run_ids(self) -> [str]:
        """A convenience function to return only the latest versions run_ids for a registred model. This is how we will bound
        the total number of run_ids that are in scope for a migration."""
        return [r.run_id for r in self.registered_model.latest_versions]
    
    def _get_registered_model_versions(self) -> [ModelVersion]:
        with self.mlflow_client() as client:
            return client.search_model_versions(filter_string=f"name='{self.registered_model_name}'")

    @abstractmethod
    def model_versions(self) -> [WsRegisteredModelVersion]:
        """This method must be overridden in subclasses."""
        pass

    def _get_experiments(self) -> [Experiment]:
        """To find all parent experiments for a registered model."""
        with self.mlflow_client() as client:
            model_versions = client.search_model_versions(filter_string=f"name='{self.registered_model_name}'")
            run_ids = set([mv.run_id for mv in model_versions])
            experiment_ids = set([client.get_run(r).info.experiment_id for r in run_ids])
            return [client.get_experiment(e) for e in experiment_ids]

    @abstractmethod
    def model_experiments(self) -> [ModelExperiment]:
        """This method must be overridden in subclasses."""
        pass

    def status(self):
        self._rm_status()
        self._rm_ver_status()
        self._exp_status()
    
    @abstractmethod
    def _rm_status(self):
        pass

    def _rm_ver_status(self):
        for v in self.model_versions:
            v.status()

    def _exp_status(self):
        for e in self.model_experiments:
            e.status()


class WsRegisteredModel(RegisteredModelBase):

    def __init__(self,
                 registered_model_name: str,
                 tracking_uri="databricks",
                 registry_uri="databricks"):
        self._rm_name = registered_model_name
        self._tracking_uri = tracking_uri
        self._registry_uri = registry_uri

    @override
    @cached_property
    def model_experiments(self) -> [SrcModelExperiment]:
        return [SrcModelExperiment(experiment_id=e.experiment_id,
                                   tracking_uri=self._tracking_uri) for e in self._get_experiments()]

    @override
    @cached_property
    def model_versions(self) -> [WsRegisteredModelVersion]:
        return [WsRegisteredModelVersion(registered_model_name=v.name,
                                         registered_model_version=v.version,
                                         registry_uri=self._registry_uri)
                for v in self._get_registered_model_versions()]

    @override
    def _rm_status(self):
        print(f'Source Registered Model, {self.__class__.__name__}, name: {self.registered_model_name}')
    

class UcRegisteredModel(RegisteredModelBase):

    _src_rm: WsRegisteredModel
    _artifact_location: str

    def __init__(self,
                 registered_model_name: str,
                 src_rm: WsRegisteredModel,
                 tracking_uri="databricks",
                 registry_uri="databricks-uc",
                 artifact_location: str = None):
        self._rm_name = registered_model_name
        self._src_rm = src_rm
        self._tracking_uri = tracking_uri
        self._registry_uri = registry_uri
        self._artifact_location = artifact_location

    @override
    @cached_property
    def model_experiments(self) -> [TgtModelExperiment]:
        """Will get or create TgtModelExperiment for all parent experiments"""
        # Will require iterating through src_rm.
        # This iteration will take the following form:
        #        Identify all src_rm.model_experiments and create experiment_name
        #           Experiment name will be deterministically assigned reusing the name of the existing experiment
        return [TgtModelExperiment(src_exp=e,
                                   src_exp_run_migrate_ids=self._src_rm.latest_version_run_ids,
                                   tracking_uri=self._tracking_uri,
                                   artifact_location=self._artifact_location)
                for e in self._src_rm.model_experiments]

    @override
    @property
    def model_versions(self) -> [WsRegisteredModelVersion]:
        """Unlike the source models_versions, this will return only the subset of migrated model_versions."""
        return [UcRegisteredModelVersion(ws_registered_model_version=v,
                                         registry_uri=self._registry_uri)
                for v in self._src_rm.model_versions if
                v.model_version.run_id in self._src_rm.latest_version_run_ids]

    @override
    def _rm_status(self):
        print(f'Target Registered Model, {self.__class__.__name__}, name: {self.registered_model_name}')
    
    @override
    def _rm_ver_status(self):
        for v in self.model_versions:
            v.status()
    
    def initialize_tgt_runs(self):
        for v in self.model_experiments:
            v.initialize_tgt_runs()

    def upgrade_tgt_experiments(self):
        for v in self.model_experiments:
            v.upgrade_tgt_experiments()


