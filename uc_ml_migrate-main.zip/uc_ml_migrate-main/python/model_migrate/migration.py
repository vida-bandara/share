from model_migrate.registered_model import WsRegisteredModel, UcRegisteredModel
from model_migrate.model_experiment import SrcModelExperiment, TgtModelExperiment


class RegisteredModelMigration:

    src_rm: WsRegisteredModel
    tgt_rm: UcRegisteredModel

    def __init__(self,
                 ws_registered_model_name: str,
                 uc_registered_model_name: str,
                 ws_tracking_uri: str = "databricks",
                 ws_registry_uri: str = "databricks",
                 uc_tracking_uri: str = "databricks",
                 uc_registry_uri: str = "databricks-uc",
                 uc_artifact_location: str = None):
        self.src_rm = WsRegisteredModel(registered_model_name=ws_registered_model_name,
                                        tracking_uri=ws_tracking_uri,
                                        registry_uri=ws_registry_uri)
        self.tgt_rm = UcRegisteredModel(registered_model_name=uc_registered_model_name,
                                        src_rm=self.src_rm,
                                        tracking_uri=uc_tracking_uri,
                                        registry_uri=uc_registry_uri,
                                        artifact_location=uc_artifact_location)

    @property
    def src_exps(self) -> [SrcModelExperiment]:
        return self.src_rm.model_experiments

    @property
    def tgt_exps(self) -> [TgtModelExperiment]:
        return self.tgt_rm.model_experiments

    def status(self):
        self.src_rm.status()
        self.tgt_rm.status()

    def initialize_tgt_entities(self):
        # This will initialize the following target entities:
        #   - UC Registered Models
        #   - Target Experiments
        #   - Target Experiment Runs
        # NOTE: This initialization does not attempt any content migration.
        #       This is written as a separate step to ensure UC/WS Permissions.
        self.tgt_rm.initialize_tgt_entities()
