from abc import abstractmethod
from typing import override
from functools import cached_property
from mlflow.entities.experiment import Experiment
from mlflow.entities.run import Run

from model_migrate.mlflow import MLFlowEntityBase
from model_migrate.experiment_run import ExperimentRun, SrcExperimentRun, TgtExperimentRun
# NOTE: The migrate convention is to have the experiment_name for the src experiments be the same experiment
#       name + "_uc". There is no intention to make this configurable by experiment, you must manually rename
#       after migration if alternate name is required.
# There is intention to map experiment runs with the same details they had in the source experiment


class ModelExperiment(MLFlowEntityBase):

    _experiment_id: str
    _experiment_name: str
    _artifact_location: str

    @property
    def experiment_id(self):
        return self._experiment_id

    @property
    def experiment_name(self):
        return self._experiment_name

    @property
    def artifact_location(self):
        return self._artifact_location

    def _set_experiment_id_name(self,
                                experiment_id: str = None,
                                experiment_name: str = None,
                                artifact_location: str = None):
        with self.mlflow_client() as client:
            if experiment_id: 
                experiment = client.get_experiment(experiment_id)
                print("Successfully identified experiment: " + experiment.name)
                self._experiment_name = experiment.name
                self._experiment_id = experiment.experiment_id
            elif experiment_name:
                experiment_name = experiment_name[10:] if experiment_name[:10] == "/Workspace" else experiment_name
                try:
                    if artifact_location:
                        self._experiment_id = client.create_experiment(name=experiment_name,
                                                                       artifact_location=artifact_location)
                    else:
                        self._experiment_id = client.create_experiment(name=experiment_name)
                    print("Successfully created experiment: " + experiment_name)
                    self._experiment_name = experiment_name
                except:
                    # TODO: make exception explicit
                    experiment = client.get_experiment_by_name(experiment_name)
                    print("Identified existing experiment: " + experiment.name)
                    self._experiment_id = experiment.experiment_id
                    self._experiment_name = experiment_name
            else:
                raise BaseException("Must supply either an experiment_id or an experiment_name")

    @property
    def experiment(self) -> Experiment:
        with self.mlflow_client() as client:
            return client.get_experiment(self.experiment_id)

    def _get_experiment_runs(self) -> [Run]:
        """To find all experiment runs within this experiment"""
        with self.mlflow_client() as client:
            return client.search_runs(experiment_ids=[self.experiment_id,])
        
    def _set_artifact_location(self, artifact_location):
        if artifact_location:
            artifact_location = artifact_location if artifact_location[:5] == "dbfs:" \
                else "dbfs:" + artifact_location
            name = self._experiment_name.split('/')[-1]
            if artifact_location[-1] == "/":
                self._artifact_location = f"{artifact_location}{name}"
            else:
                self._artifact_location = f"{artifact_location}/{name}"

    @abstractmethod
    def experiment_runs(self) -> [ExperimentRun]:
        """This method must be overridden in subclasses."""
        pass

    def status(self):
        self._exp_status()
        self._exp_run_status()

    @abstractmethod
    def _exp_status(self):
        pass

    def _exp_run_status(self):
        for r in self.experiment_runs:
            r.status()



class SrcModelExperiment(ModelExperiment):

    def __init__(self,
                 experiment_id: str,
                 tracking_uri: str = None):
        self._tracking_uri = tracking_uri
        self._set_experiment_id_name(experiment_id=experiment_id)

    @override
    @cached_property
    def experiment_runs(self) -> [ExperimentRun]:
        return [SrcExperimentRun(run_id=r.info.run_id) for r in self._get_experiment_runs()]

    @override
    def _exp_status(self):
        print(f'    Source Experiment, {self.__class__.__name__}, name: {self.experiment_name}')


class TgtModelExperiment(ModelExperiment):

    _src_exp: SrcModelExperiment
    _src_exp_run_migrate_ids: [str]

    def __init__(self,
                 src_exp: SrcModelExperiment,
                 src_exp_run_migrate_ids: [str] = [],
                 tracking_uri: str = None,
                 artifact_location: str = None):
        self._src_exp = src_exp
        self._src_exp_run_migrate_ids = src_exp_run_migrate_ids
        self._experiment_name = src_exp.experiment_name + "_uc"
        self._tracking_uri = tracking_uri
        self._set_artifact_location(artifact_location)
        self._set_experiment_id_name(experiment_name=self._experiment_name,
                                     artifact_location=self._artifact_location)
    
    @override
    @cached_property
    def experiment_runs(self) -> [ExperimentRun]:
        """Unlike source experiment run where all runs are returned, in target experiment, only those runs in src_exp_run_migrate_ids returned."""
        return [TgtExperimentRun(experiment_id=self.experiment_id,
                                 src_exp_run=src_exp_run) for src_exp_run in self._src_exp.experiment_runs
                if src_exp_run.run_id in self._src_exp_run_migrate_ids]

    @override
    def _exp_status(self):
        print(f'    Target Experiment, {self.__class__.__name__}, name: {self.experiment_name}')

    def initialize_tgt_runs(self):
        for r in self.experiment_runs:
            r.initialize_tgt_runs()

    def upgrade_tgt_experiments(self):
        self._upgrade_experiment_description()


    def _upgrade_experiment_description(self):
        description = self.experiment.tags.get('mlflow.note.content', None)
        if not description:
            src_description = self._src_exp.experiment.tags.get('mlflow.note.content', "")
            desc = f"Upgraded from experiment_id {self._src_exp.experiment_id}. {src_description}"
            with self.mlflow_client() as client:
                client.set_experiment_tag(self.experiment_id, "mlflow.note.content", desc)

