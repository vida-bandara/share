from model_migrate.mlflow import MLFlowEntityBase

from mlflow.entities.model_registry import ModelVersion

from functools import cached_property
from abc import abstractmethod
from typing import override


class RegisteredModelVersion(MLFlowEntityBase):

    @abstractmethod
    def status(self):
        pass

class WsRegisteredModelVersion(RegisteredModelVersion):

    name: str
    version: str

    def __init__(self,
                 registered_model_name: str,
                 registered_model_version: str,
                 registry_uri: str):
        self._registry_uri = registry_uri
        self._set_registered_model_name_versions(registered_model_name,
                                                 registered_model_version)

    def _set_registered_model_name_versions(self,
                                            registered_model_name: str,
                                            registered_model_version: str):
        self.name = registered_model_name
        self.version = registered_model_version
        _ = self.model_version

    @cached_property
    def model_version(self) -> ModelVersion:
        with self.mlflow_client() as client:
            return client.get_model_version(name=self.name,
                                            version=self.version)
    
    @override
    def status(self):
        print(f'      Source Registered Model Version, {self.__class__.__name__}, name: {self.name}-{self.version}')


class UcRegisteredModelVersion(RegisteredModelVersion):

    _ws_registered_model_version: WsRegisteredModelVersion

    def __init__(self,
                 ws_registered_model_version: WsRegisteredModelVersion,
                 registry_uri: str):
        self._ws_registered_model_version = ws_registered_model_version
        self._registry_uri = registry_uri

    @override
    def status(self):
        print(f'      Target Registered Model Version, {self.__class__.__name__} target instance of source {self._ws_registered_model_version.name}-{self._ws_registered_model_version.version}')
