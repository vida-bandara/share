from abc import ABC
from contextlib import contextmanager

import mlflow
from mlflow.tracking import MlflowClient


class MLFlowEntityBase(ABC):
    """Base Class when working with MLFlow Entities that may have custom tracking_uri and/or registry_uri"""

    _tracking_uri: str = "databricks"
    _registry_uri: str = "databricks-uc"

    @contextmanager
    def mlflow_client(self):
        global_tracking_uri = mlflow.get_tracking_uri()
        global_registry_uri = mlflow.get_registry_uri()
        mlflow.set_tracking_uri(self._tracking_uri)
        mlflow.set_registry_uri(self._registry_uri)
        try:
            yield MlflowClient(tracking_uri=self._tracking_uri,
                               registry_uri=self._registry_uri)
        finally:
            mlflow.set_tracking_uri(global_tracking_uri)
            mlflow.set_registry_uri(global_registry_uri)
