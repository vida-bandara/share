# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # MLFlow Tag Limits
# MAGIC
# MAGIC This notebook is provided only to do discovery on limits of tags. These tags limits should be consistant across cloud regions and consisant with what is documented in [resource limits](https://docs.databricks.com/en/resources/limits.html). However, deviations can happen and can be confirmed using this reference code.
# MAGIC

# COMMAND ----------

# DBTITLE 1,Install Dependencies
# MAGIC %pip install --upgrade "mlflow-skinny[databricks]"
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## MLFlow Experiment
# MAGIC
# MAGIC The first non-notebook / script entity created in the model development lifecycle is the [experiment](https://docs.databricks.com/en/mlflow/experiments.html). Below, we will create an experiment and show it can support 3 tags however there is a hard [upper limit of 1000 tags](https://learn.microsoft.com/en-us/azure/databricks/resources/limits).
# MAGIC
# MAGIC **NOTE**: Unlike the MLFlow experiment-run tags, the experiment tags can only be used via the API, there is not a way to inspect them in Databricks Experiments view.
# MAGIC
# MAGIC **NOTE**: The code below allows for the creation of either a UC Volume Archive or a DBFS Archive. Either are acceptable for this testing.
# MAGIC
# MAGIC **NOTE**: There are two experiment locality types: [notebook](https://docs.databricks.com/en/mlflow/experiments.html?utm_source=chatgpt.com#create-notebook-experiment) & [workspace](https://docs.databricks.com/en/mlflow/experiments.html?utm_source=chatgpt.com#create-workspace-experiment). This script is a workspace example becuase `experiment_name` is a workspace path.

# COMMAND ----------

# DBTITLE 1,Get / Create Workspace Experiment
import mlflow
from mlflow.tracking import MlflowClient


client = MlflowClient()

experiment_name = "/Workspace/experiments/uc_ml_migrate/tag_limit"
artifact_path = f"dbfs:/Volumes/main/default/experiments/tag_limit/"
UC_VOLUME_ARCHIVE = False

mlflow.set_tracking_uri("databricks")
mlflow.set_registry_uri("databricks-uc")

# Get / Create experiment
if UC_VOLUME_ARCHIVE:
    try:
        experiment_id = client.create_experiment(name=experiment_name)
        for i in range(3):
            client.set_experiment_tag(experiment_id, f"exp_tag{i}", i)
    except:
        # Need to drop /Workspace when using get_experiment_by_name
        experiment_id = client.get_experiment_by_name(name=experiment_name[10:]).experiment_id
else:
    try:
        experiment_id = client.create_experiment(name=experiment_name, artifact_location=artifact_path)
        for i in range(3):
            client.set_experiment_tag(experiment_id, f"exp_tag{i}", i)
    except:
        # Need to drop /Workspace when using get_experiment_by_name
        experiment_id = client.get_experiment_by_name(name=experiment_name[10:]).experiment_id

# COMMAND ----------

client.get_experiment(experiment_id).tags

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## MLFLow Experiment-Run
# MAGIC
# MAGIC Within an experiement you can create experiment runs. This is also where you can log a model. We'll log a simple [PythonModel](https://mlflow.org/docs/latest/python_api/mlflow.pyfunc.html?highlight=pythonmodel#mlflow.pyfunc.PythonModel). Within the same experiment run we'll log the following attributes:
# MAGIC
# MAGIC | Attribute | Puspose |
# MAGIC | --------- | ------- | 
# MAGIC | Parameters | Logs the input configuration or hyperparameters (e.g., learning rate, number of layers) used during the execution of a machine learning model. Parameters are essential for tracking and comparing runs, as they help identify how different configurations influence model performance. |
# MAGIC | Metrics    | Log metrics to track the performance of your model or experiment over time, such as accuracy, loss, or precision. Metrics are crucial for evaluating and comparing runs, enabling you to identify trends, select the best-performing models, and make data-driven improvements. |
# MAGIC | Tags      | Descriptive metadata that helps categorize or contextualize the run, such as specifying the purpose, team, or version of the dataset used. Tags make it easier to filter, search, and group runs within the experiment, especially in collaborative or large-scale projects. |
# MAGIC
# MAGIC It is a common practice to log metrics and parameters as well as set tags using the mlflow using the managed context, [`mlflow.start_run`](https://mlflow.org/docs/latest/python_api/mlflow.html?highlight=start_run#mlflow.start_run). Which is why this tag management section looks different. However, this is ultimately calling the equivalent method [mlflow.client.MlflowClient.set_tag](https://mlflow.org/docs/latest/python_api/mlflow.client.html?highlight=mlflowclient%20set_tag#mlflow.client.MlflowClient.set_tag). 
# MAGIC
# MAGIC For all of the attributes above (parameter, metric, tag), the upper [limit is +1600](https://learn.microsoft.com/en-us/azure/databricks/resources/limits) entries.
# MAGIC

# COMMAND ----------

import mlflow 
import pandas as pd
from mlflow.models.signature import infer_signature

class AddTenModel(mlflow.pyfunc.PythonModel):
    def predict(self, context, model_input):
        return model_input + 10

params = { f'param{i}': f'val{i}' for i in range(3)}
metrics = { f'metric{i}': i for i in range(3)}
tags = { f'tag{i}': f'val{i}' for i in range(3)}

mlflow.set_experiment(experiment_id=experiment_id)

with mlflow.start_run() as run:

    input_example = pd.DataFrame([{"input": 5}])
    mlflow.pyfunc.log_model(
        artifact_path="model",
        python_model=AddTenModel(),
        signature=infer_signature(input_example, input_example + 10),
        input_example=input_example
    )

    mlflow.log_params(params)
    mlflow.log_metrics(metrics)
    mlflow.set_tags(tags)

    run_id = run.info.run_id

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## UC Registered Model 
# MAGIC
# MAGIC The UC Registered Model entity is a UC entity that can still be accessed / searched via [mlflow.MlflowClient](https://mlflow.org/docs/latest/python_api/mlflow.client.html?highlight=mlflowclient#mlflow.client.MlflowClient). A model become registered when it has been identified as a candidate model that has passed validation and able to be served. You are able to set tags using [MlflowClient.set_registered_model_tag](https://mlflow.org/docs/latest/python_api/mlflow.client.html?highlight=set_registered_model_tag#mlflow.client.MlflowClient.set_registered_model_tag).
# MAGIC
# MAGIC You use set_registered_model_tag to store metadata about the model at the registry level, such as its intended use (e.g., "production" or "staging") or its associated team. This helps in organizing and filtering registered models, making it easier to track their purpose, status, or ownership across different environments.
# MAGIC
# MAGIC
# MAGIC
# MAGIC It is used to identify those models that have passed validation for production and are ready to be evaluated for champion selection in production model serving. 
# MAGIC
# MAGIC The registered model itself has 10 tags and those tags are typically a descriptor of application ownership and billing as well use for listing dependent applications. Tags do not typically include permissions since there is a deticated framework for that. Tags do not typically copy the model parameters, metrics, and tags of the experiment-run that they came from.
# MAGIC
# MAGIC **NOTE**: There is an engineered hard limit of 20 to the number of tags that can be assigned to a UC Registered Model. If you increase the number in the test below, you'll see a coresponding exception message.
# MAGIC
# MAGIC **NOTE**: An expected behavior of register model is if you run it again it will create a new model version.
# MAGIC
# MAGIC **NOTE**: There is an active ES ticket, [ES-1343596](https://databricks.atlassian.net/browse/ES-1343596),  requesting an increase to the number of tags permitted. 

# COMMAND ----------

import mlflow 
from mlflow import MlflowClient
mlflow.set_registry_uri("databricks-uc")
client = MlflowClient()


model_name = 'main.default.addten'

mlflow.set_registry_uri("databricks-uc")
mdl_version = mlflow.register_model(model_uri=f'runs:/{run_id}/model',
                                    name=model_name)

# Inspect if tags have already been applied to the registered model, if not, add some
#for t in range(20):
#    ?client.set_registered_model_tag


# COMMAND ----------

dir(client)

# COMMAND ----------

from mlflow.tracking import MlflowClient

mlflow.set_registry_uri("databricks-uc")

# Initialize the MLflow client
client = MlflowClient()

dir(client)

# COMMAND ----------

?client.set_registered_model_tag

# COMMAND ----------



# Define model details
model_name = "biomed_genai.models.foundation_lc_rag"  # Replace with your model name
model_version = "25"  # Replace with the specific model version

# Define the tag
tag_key = "project"
tag_value = "customer-segmentation"

# Add the tag to the specified model version
client.set_model_version_tag(name= "biomed_genai.models.foundation_lc_rag",
                             version=25,
                             key="key0",
                             value="val1")

# COMMAND ----------

# Create a dict of tags to be applied to an experiment run
# We'll use dict since this is the most likely format to be used by ml developers
tags = { f'tag{i}': f'val{i}' for i in range(100)}

# COMMAND ----------

def dict_lister(tags):
    # helper method to convert large tags dict into list of smaller dicts
    dict_list = []
    current_dict = {}
    
    for i, (key, value) in enumerate(tags.items()):
        current_dict[key] = value
        if (i + 1) % 20 == 0:
            dict_list.append(current_dict)
            current_dict = {}
    
    if current_dict:
        dict_list.append(current_dict)

    return dict_list

# COMMAND ----------

import mlflow

def set_large_tags(tags):
    # helper method to load a large number of tags
    for tags in dict_lister(tags):
        mlflow.set_tags(tags)

# COMMAND ----------

import mlflow 

# Test loading all tags
with mlflow.start_run() as run:
    set_large_tags(tags)


# COMMAND ----------

#An example of what happens when attempting to pass all tags in a single call

with mlflow.start_run() as run:
    mlflow.set_tags(tags)

# COMMAND ----------

# MAGIC %pip install --upgrade "mlflow-skinny[databricks]"
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

import mlflow 
from mlflow import MlflowClient
mlflow.set_registry_uri("databricks-uc")
client = MlflowClient()

client.rename_registered_model("biomed_genai.models.test", "test2")

# COMMAND ----------

?client.set_model_version_tag

# COMMAND ----------

for i in range(100):
    #client.set_registered_model_tag("biomed_genai.models.test2", f"k{i}", f"v{i}")
    client.set_model_version_tag("biomed_genai.models.foundation_lc_rag", "25", f"k{i}", f"v{i}")

# COMMAND ----------

client.search_registered_models(filter_string="name = 'biomed_genai.models.foundation_lc_rag'")

# COMMAND ----------

dir(client)

# COMMAND ----------

from mlflow.tracking import MlflowClient

mlflow.set_registry_uri("databricks-uc")

# Initialize the MLflow client
client = MlflowClient()

# Define model details
model_name = "biomed_genai.models.foundation_lc_rag"  # Replace with your model name
model_version = "25"  # Replace with the specific model version

# Define the tag
tag_key = "project"
tag_value = "customer-segmentation"

# Add the tag to the specified model version
client.set_model_version_tag(name= "biomed_genai.models.foundation_lc_rag",
                             version=25,
                             key="key0",
                             value="val1")

# COMMAND ----------

?client.set_model_version_tag

# COMMAND ----------

import mlflow

mlflow.set_registry_uri("databricks-uc")



    model_name = "model" #Compound_rag_chat.model_name
    mdl_version: ModelVersion = mlflow.register_model(model_uri=f'runs:/{run_info.run_id}/{model_name}',
                                                      name=f'{catalog}.{schema}.{model_name}')
    return mdl_version



from mlflow import MlflowClient

# Initialize the MLflow client
client = MlflowClient()

# Define the model name and version
model_name = "biomed_genai.models.foundation_lc_rag"
model_version = "25"

# Define the tags to be added
tags = {
    "tag1": "val1",
    "tag2": "val2"
}

# Add tags to the specified model version
for key, value in tags.items():
    client.set_model_version_tag(model_name, model_version, key, value)

# COMMAND ----------

# DBTITLE 1,Tag Limits in Model Serving
import requests
import json

# Define the URL for the model serving endpoint
url = "https://adb-830292400663869.9.azuredatabricks.net/api/2.0/serving-endpoints/model/invocations"

# Define the headers, including the authorization token
headers = {
    "Authorization": "Bearer <your_access_token>",
    "Content-Type": "application/json"
}

# Define the payload with the tag
payload = {
    "tags": {
        "quality": "good"
    }
}

# Make the POST request to add the tag
response = requests.post(url, headers=headers, data=json.dumps(payload))

# Check the response
if response.status_code == 200:
    print("Tag added successfully.")
else:
    print(f"Failed to add tag. Status code: {response.status_code}, Response: {response.text}")
